import React, { useState , useEffect} from 'react'
import Child from './Child';

function App() {
  const [count , setCount]=useState(0);
  return (
    <>
   <Child count={count}/>
    <button onClick={()=>{setCount(count+1)}}>  click</button>
    </>
  )
}

export default App