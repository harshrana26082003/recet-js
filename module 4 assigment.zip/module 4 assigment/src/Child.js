import React, { useState , useEffect} from 'react'

function Child(props) {
    
    useEffect(()=>{
      
    },[props.count==3])
  return (
    <>
    <div>Chlid</div>
    <h2>{props.count}</h2>
    </>
  )
}

export default Child