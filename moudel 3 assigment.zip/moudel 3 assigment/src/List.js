import React from 'react'

 const List = (props) => {

    const data =[
        {
            name : "marry",
            age : 25
        },
         {
            name : "alan",
            age : 23
        },
         {
            name : "ram",
            age : 15
        },
         {
            name : "shyam",
            age : 20
        },
    ]



  return (
    <div>
        {
            data.map((element , index)=>{
                return<div key={index}>
                    {element.name} is {element.age} years old
                </div>
            })
        }
    </div>
  )
}
export default List;