import React from 'react'

function App() {
  return (
    <div>List View :-</div>
  )
}

export default App