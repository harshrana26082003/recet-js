import React, { useState } from 'react'
import "./Hook.css"

const Hook = () => {

  const[num, setNum]=useState(0)

  const incNum = ()=>{
    setNum(num+1);
  }
  const DecNum = ()=>{
    if(num>0){
    setNum(num-1);
  }else{
    alert("sorry, zero is limt reach ")
    setNum(0)
  }
  }


  return (
    <>
      <div className='Main-div'>
        <div className='Center_div'>
          <h1>{num}</h1>
          <div className='btn_div'>
            <button onClick={incNum}>Increment</button>
            <button onClick={DecNum}>Decrement</button>
          </div>
        </div>
      </div>
    </>
  )
}

export default Hook
