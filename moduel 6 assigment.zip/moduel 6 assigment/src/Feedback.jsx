import React from "react";
import './Feedback.css'
function Feedback(){
    return <>
        
        <div class="  text-center feedback">This is my Feedback Us PAge </div>

    </>;
}
export default Feedback;