import React from 'react'
import './Footer.css'
export default function Footer() {
  return (

      <div class=" text-bg-success text-center Footer"> All rights reserved to TOPS @ 2023</div>
  )
}