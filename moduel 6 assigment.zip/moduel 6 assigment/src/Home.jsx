import React from "react";
import './Home.css'
function Home(){
    return <>
    <div class=" text-bg-primary text-center home"> This is my Home Us PAge</div>
       
    </>;
}
export default Home;