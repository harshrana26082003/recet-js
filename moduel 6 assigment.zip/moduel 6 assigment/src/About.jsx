import React from "react";
import './About.css'
function About(){
    return <>
        <div class="  text-center about"> This is my About Us PAge</div>
    </>;
}
export default About;