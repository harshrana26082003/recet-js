import {Route,Routes } from "react-router-dom";
import About from './About';
import Contact from './Contact';
import Feedback from './Feedback';
import Home from './Home';
import Navbar from './Navbar';
import Error from './Error';
import Footer from './Footer';


function App() {
  return (
   <>
   <Navbar/>
   <Routes>
    <Route exact path="/feedback" Component={Feedback}></Route>
    <Route exact path="/" Component={Home}></Route>
    <Route exact path="/Contact" Component={Contact}></Route>
    <Route exact path="/About" Component={About}></Route>
    <Route exact path="/*" Component={Error}></Route>
   </Routes>
   <Footer/>

   </>
  );
}

export default App;
