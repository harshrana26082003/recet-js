import React from "react";
import './Error.css'
function Error(){
    return <>
        <div class="  text-center Error"> 404 page not found !!!!! </div>
    </>;
}
export default Error;