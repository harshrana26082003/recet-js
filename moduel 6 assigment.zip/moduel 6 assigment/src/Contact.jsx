import React from "react";
import './Contact.css'
function Contact(){
    return <>
        
        <div class="  text-center contact"> This is my Contact Us PAge </div>
    
    </>;
}
export default Contact;